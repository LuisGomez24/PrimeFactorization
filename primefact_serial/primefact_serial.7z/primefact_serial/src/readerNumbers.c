// Copyright 2021 Luis Fernando Gomez Sanchez C03309

#include "./readerNumbers.h"
#include <stdio.h>
#include <stdlib.h>
#include <inttypes.h>
#include <stdint.h>
#include <errno.h>
#include <string.h>
#include <stdbool.h>
#include "./structures.h"

void readerNumbers(numberList* listNumbers) {
  int64_t value = 0;
  while ( scanf("%" SCNd64, &value) == 1 ) {
    number* auxiliarNode = malloc(sizeof(number));
    initNumberNode(auxiliarNode);
    if (listNumbers->firstNumber == NULL) {
      listNumbers->firstNumber = auxiliarNode;
      listNumbers->firstNumber->value = value;
      listNumbers->lastNumber = auxiliarNode;
    } else {
      listNumbers->lastNumber->nextNumber = auxiliarNode;
      listNumbers->firstNumber->nextNumber->value = value;
      listNumbers->lastNumber = auxiliarNode;
    }
  }
  // free(auxiliarNode);
  /*
  if (errno != 0) {
    perror("Error: ");
    exit(1);
  }*/
  // return true
}
