// Copyright 2021 Luis Fernando Gomez Sanchez C03309

#include "./factorization.h"
#include <stdio.h>
#include <stdlib.h>
#include <inttypes.h>
#include <stdint.h>
#include <stdbool.h>
#include <math.h>
#include "./structures.h"

bool isPrime(int64_t number) {
  for ( int64_t divisors = 2; divisors <= sqrt(number); divisors++ ) {
    if (number % divisors == 0) {
      return false;
    }
  }
  return true;
}

void addFactor(number* number, int64_t newFactor) {
  if (number->lastFactor->factorValue == newFactor) {
    number->lastFactor->exponent += 1;
  } else {
      factor* auxiliarFactor = number->lastFactor->nextFactor;
      initFactorNode(auxiliarFactor);
      number->lastFactor->nextFactor->factorValue = newFactor;
      number->lastFactor = number->lastFactor->nextFactor;
      free(auxiliarFactor);
  }
}

void calculateFactorsOfNumber(number* number) {
  int64_t numberValue = number->value;
  if (numberValue > 1) {
    int64_t currentFactor;
    for (currentFactor = 2; currentFactor <= numberValue; currentFactor++) {
      while (isPrime(currentFactor) && (number->value % currentFactor == 0)) {
        if (number->firstFactor == NULL) {
          factor* auxiliarFactor = number->firstFactor;
          initFactorNode(auxiliarFactor);
          number->firstFactor->factorValue = currentFactor;
          number->lastFactor = number->firstFactor;
          free(auxiliarFactor);
        } else {
          addFactor(number, currentFactor);
        }
        numberValue = numberValue / currentFactor;
      }
    }
  } else if (numberValue == 0 || numberValue == 1) {
    number->firstFactor->factorValue = 1;
  } else {
    number->firstFactor->factorValue = -1;
  }
}

void calculateFactors(numberList* numberList) {
  number* auxiliarNode = numberList->firstNumber;
  while (auxiliarNode != NULL) {
    calculateFactorsOfNumber(auxiliarNode);
    auxiliarNode = auxiliarNode->nextNumber;
  }
  free(auxiliarNode);
}
