// Copyright 2021 Luis Fernando Gomez Sanchez C03309

#include "./structures.h"
#include <inttypes.h>
#include <stdint.h>
#include <stdlib.h>
#include <stdio.h>
#include <assert.h>

void initFactorNode(factor* factorNode) {
  factorNode = malloc(sizeof(factor));
  factorNode->factorValue = 0;
  factorNode->exponent = 1;
  factorNode->nextFactor = NULL;
}

void initNumberNode(number* numberNode) {
  numberNode = malloc(sizeof(number));
  numberNode->value = 0;
  numberNode->nextNumber = NULL;
  numberNode->firstFactor = NULL;
  numberNode->lastFactor = NULL;
}

void initNumberListNode(numberList* numbers) {
  numbers = malloc(sizeof(numberList));
  numbers->firstNumber = NULL;
  numbers->lastNumber = NULL;
}

void destroyList(numberList* numberList) {
  assert(numberList);
  for (number* currentNumber = numberList->firstNumber;
       currentNumber; currentNumber = numberList->firstNumber) {
    for (factor* currentFactor= currentNumber->firstFactor;
         currentFactor; currentFactor = currentNumber->firstFactor) {
      currentNumber->firstFactor = currentFactor->nextFactor;
      free(currentFactor);
    }
    numberList->firstNumber = currentNumber->nextNumber;
    free(currentNumber);
  }
  initNumberListNode(numberList);
  free(numberList);
}
