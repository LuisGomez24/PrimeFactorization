// Copyright 2021 Luis Fernando Gomez Sanchez C03309

#include <stdlib.h>
#include "./readerNumbers.h"
#include "./structures.h"
#include "./factorization.h"
#include "./printFactors.h"

int main(void) {
  numberList* numberList = NULL;
  initNumberListNode(numberList);
  readerNumbers(numberList);
  calculateFactors(numberList);
  printFactorization(numberList);
  destroyList(numberList);
  return 0;
}
