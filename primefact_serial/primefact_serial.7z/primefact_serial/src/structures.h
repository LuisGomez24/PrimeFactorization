// Copyright 2021 Luis Fernando Gomez Sanchez C03309

#ifndef STRUCTURES_H_
#define STRUCTURES_H_
#include <inttypes.h>
#include <stdint.h>

/*
typedef struct factor;
typedef struct number;
typedef struct numberList;
*/

typedef struct factor factor;
typedef struct number number;

typedef struct factor {
  int64_t factorValue;
  int64_t exponent;
  factor* nextFactor;
} factor;

typedef struct number {
  int64_t value;
  factor* firstFactor;
  factor* lastFactor;
  number* nextNumber;
} number;

typedef struct numberList {
  number* firstNumber;
  number* lastNumber;
} numberList;

/**
 @brief Inicializa los valores de un nodo @a factor
 @param factor con un nodo @a factor inicializado
*/
void initFactorNode(factor* factor);

/**
 @brief Inicializa los valores de un @a number
 @param number con un nodo @a number inicializado
*/
void initNumberNode(number* number);

/**
 @brief Inicializa los valores de un nodo @a numberList
 @param numberList con un nodo @a numberList inicializado
*/
void initNumberListNode(numberList* numberList);

/**
 @brief Libera el espacio reservado para @a numberList
 @param numberList con un nodo @a numberList inicializado
*/
void destroyList(numberList* numberList);

#endif  // STRUCTURES_H_
