# PrimeFact_Serial

## Autor
Estudiante: Luis Fernando Gomez Sanchez
Carnet: C03309s

### Problema a resolver: 
El programa recibe de la entrada estándar un conjunto de número enteros que almacenará en memoria para luego calcular su factorización prima. Si la entrada recibe un número negativo, imprime 'invalid number' en la salida estándar; si la entrada recibe un 1 o un 0, imprime 'NA' en la salida estándar; si la entrada recibe un numero entero cualquiera, la salida estandar mostrará su factorización prima; si la entrada estándar recibe cualquier otro conjunto de caracteres, la salida mostrará un aviso de error.

#### Creditos
- El modulo de Factorización está inspirado en el realizado por John Ortiz Ordoñez, recuperado de:
  https://github.com/Fhernd/JavaScriptEjercicios/blob/master/Parte001/ex787-factores-primos-unicos-numero-funcion.js
